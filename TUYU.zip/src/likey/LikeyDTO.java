package likey;

public class LikeyDTO {
	String USEREMAIL;
	String ID;
	String USERIP;
	
	public String getUSEREMAIL() {
		return USEREMAIL;
	}
	public void setUSEREMAIL(String uSEREMAIL) {
		USEREMAIL = uSEREMAIL;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getUSERIP() {
		return USERIP;
	}
	public void setUSERIP(String uSERIP) {
		USERIP = uSERIP;
	}
}
